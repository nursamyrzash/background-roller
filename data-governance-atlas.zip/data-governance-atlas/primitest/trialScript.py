import pandas as pd
import requests
import json


trial_dataframe = pd.read_excel('MdG - Metadata Management Casellario Giudiziario v.1.0.xlsx', sheet_name=2)


dataframe_dict = trial_dataframe.to_dict('list')
dataframe_dict_records = trial_dataframe.to_dict(orient='records')

# print(dataframe_dict_records[0]["Nome del Dataset"])

for values in dataframe_dict_records:
    names = values["Nome del Dataset"]
    print(f"{names}\n")
    if values["Nome del Dataset"] == "DS_SIC_DC_CG_ANAG_PERS_FISICHE_TAB_DIM":
        print(values["Nome del Dataset"])

def preparing_data(dataframe):
    df2 = dataframe[dataframe.columns[0:]]
    return df2

new_data = preparing_data(trial_dataframe)

# print(new_data["Nome del Dataset"][0])
# print(type(new_data["Nome del Dataset"][0]))
# print(type(new_data))

# for name in new_data["Nome del Dataset"]:
# #     if name == name_from_table:
#     print(name)

# for values in dataframe_dict:
#     print(dataframe_dict[values][0])
#     value_list = str(dataframe_dict[values][0]).splitlines()
#     print(value_list)
    # for one_value in dataframe_dict[values][0]:
    #     print(one_value)
    # for content in value[content]:
    #     print(content)

# for name_dict in dataframe_dict["Nome del Dataset"]:
#     print(name_dict)
# print(dataframe_dict)

class Struct:
    def __init__(self, **kwargs):
        for key, value in kwargs.items():
            if isinstance(value, dict):
                self.__dict__[key] = Struct(**value)
            else:
                self.__dict__[key] = value

obj = Struct(**dataframe_dict)

attributes = obj.__dir__()

modified_attr = attributes[0:22]

values = getattr(obj, 'Nome del Dataset')


dictionary1 = {"businessMetadataDefs": [
                {
                    "name": "codeMethadataTrial2",
                    "description": "<p>metadata from the python scrypt</p>",
                    "attributeDefs": []
                }
]}

dic2 = dictionary1["businessMetadataDefs"][0]["attributeDefs"] = modified_attr

# print(dictionary1["businessMetadataDefs"])
json_object = json.dumps(dictionary1)

dictionary_entity = {
    "entity": {
        "typeName": "hive_table",
        "attributes": {
            "owner": "",
            "modifiedTime": 0,
            "createTime": 0,
            "qualifiedName": "",
            "name": "table_test_script",
            "clusterName": "cl1"
        }
    }
}


# entity = requests.post('https://atlas.dai-training.com/api/atlas/v2/entity', json= dictionary_entity, headers={'Content-type': 'application/json'}, auth=('admin', 'admin'))

# print(entity.status_code, entity.json())

take_guid = requests.get('https://atlas.dai-training.com/api/atlas/discovery/search/dsl?limit=25&query=hive_table+where+name%3D%22table_test_script%22',headers={'Accept': 'application/json'}, auth=('admin', 'admin'))
# print(f"Status Code: {take_guid.status_code}, Content: {take_guid.json()}")

json_with_guid = take_guid.json()
# print(type(json_with_guid))


table_guid = json_with_guid['results'][0]["$id$"]['id']

# print(table_guid)

r = requests.get('https://atlas.dai-training.com/api/atlas/v2/types/typedefs', 
                 headers={'Accept': 'application/json'}, auth=('admin', 'admin'))

# print(f"Status Code: {r.status_code}, Content: {r.json()}")

# p = requests.post('https://atlas.dai-training.com/api/atlas/v2/types/typedefs', json=dic2, headers={'Content-type': 'application/json'}, auth=('admin', 'admin'))

# print(p.status_code, p.json())









