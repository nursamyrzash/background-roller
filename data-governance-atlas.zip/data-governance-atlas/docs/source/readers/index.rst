================
Template Readers
================

PyApacheAtlas provides a means for reading templates from JSON and Excel.

.. toctree::
   :maxdepth: 1
   :caption: Contents:

   excel
   excel-config
   reader
