====================
Basic Authentication
====================
.. currentmodule:: pyapacheatlas.auth.basic

.. autosummary::
   :toctree: api/

   BasicAuthentication

You can use an BasicAuthentication to authenticate to your Apache Atlas server.

.. autosummary::
   :toctree: api/

   BasicAuthentication.get_authentication_headers
