=========================
Clients for PyApacheAtlas
=========================

PyApacheAtlas's core module provides a clients and models for working with
Apache Atlas concepts.

.. toctree::
   :maxdepth: 1
   :caption: Clients

   atlasclient
   purviewclient
