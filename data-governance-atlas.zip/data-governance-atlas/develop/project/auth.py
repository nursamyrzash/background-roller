import os
from pyapacheatlas.auth import BasicAuthentication
from pyapacheatlas.core.client import AtlasClient

basic_auth = BasicAuthentication(
    username=os.environ.get("ATLAS_USERNAME", "admin"),
    password=os.environ.get("ATLAS_PASSWORD", "admin")
)

client = AtlasClient(
    endpoint_url="https://atlas.dai-training.com/api/atlas/v2",
    authentication = basic_auth
)