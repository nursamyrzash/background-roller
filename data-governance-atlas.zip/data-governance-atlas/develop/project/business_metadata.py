from pyapacheatlas.core.typedef import AtlasAttributeDef, AtlasStructDef, TypeCategory 
from auth import client

def create_bisness_metadata_table(business_metadata_dataset):
    business_metadata_dataset.remove('Nome del Dataset')
    business_metadata_dataset.remove('Descrizione Dataset')
    business_metadata_dataset.remove("Nome dell'Attributo")
    business_metadata_dataset.remove("Descrizione dell'attributo")
    formated_business_dataset = []
    for name_of_attr in business_metadata_dataset:
        name_of_attr = name_of_attr.replace('/',' or ')
        name_of_attr = name_of_attr.replace('à','a')
        formated_business_dataset.append(name_of_attr)

    attributeDefs=[]
    for name_of_attr in formated_business_dataset:
        attributeDefs.append(AtlasAttributeDef(name=name_of_attr,options={"maxStrLength": "500","applicableEntityTypes":"[\"hive_table\"]"}))

    # attributeDefs.append(AtlasAttributeDef(name='Custom Attr',options={"maxStrLength": "500","applicableEntityTypes":"[\"hive_table\"]"}))
    bisness_metadata = AtlasStructDef(
        name="SIAMM_business_metadata_hive_table_main1",
        category=TypeCategory.BUSINESSMETADATA,
        attributeDefs=attributeDefs
    )
    client.upload_typedefs(businessMetadataDefs=[bisness_metadata], force_update=True)
    print("Business meatadata for tables was created in Altas...")

def create_bisness_metadata_for_column(columns, bussiness_list):
    matched_list = [elem for elem in columns if elem in bussiness_list]
    attributeDefs=[]
    # print(matched_list)
    for name_of_attr in matched_list:
        name_of_attr = name_of_attr.replace('/',' or ')
        attributeDefs.append(AtlasAttributeDef(name=name_of_attr,options={"maxStrLength": "500","applicableEntityTypes":"[\"hive_column\"]"}))

    bisness_metadata = AtlasStructDef(
        name="SIAMM_business_metadata_for_column_main",
        category=TypeCategory.BUSINESSMETADATA,
        attributeDefs=attributeDefs
    )
    client.upload_typedefs(businessMetadataDefs=[bisness_metadata], force_update=True)
    print("Business meatadata for columns was created in Altas...")
