import json
from pyapacheatlas.core import AtlasEntity
from preproccessing import list_hive_table_type
from auth import client

def create_entities_dataset(dataset, technical_and_operational_metadata, business_metadata_dataset):
    print("Starting of table creation....")
    technical_and_operational_metadata.remove("Formato")
    technical_and_operational_metadata.remove('Nullability')
    technical_and_operational_metadata.remove('Atlas Type')


    formated_business_dataset = []
    for name_of_attr in business_metadata_dataset:
        name_of_attr = name_of_attr.replace('/',' or ')
        name_of_attr = name_of_attr.replace('à','a')
        formated_business_dataset.append(name_of_attr)

    # print(formated_business_dataset)


    for value in dataset:
        value['Dominio or Area di riferimento'] = value['Dominio/Area di riferimento']
        del value['Dominio/Area di riferimento']
        value['Descrizione entita di business'] = value['Descrizione entità di business']
        del value['Descrizione entità di business']
        value['Nome entita di Business'] = value['Nome entità di Business']
        del value['Nome entità di Business']
        value['Profondita Storica'] = value['Profondità Storica']
        del value['Profondità Storica']

        if value["Nome del Dataset"].lower() in list_hive_table_type:
            # print("it true hive_table")
            value['Atlas Type'] = "hive_table"
        else:
            # print("it false hive_table")
            value['Atlas Type'] = "hive_table"

        entity_from_server = client.get_entity(
        qualifiedName= value['QualifiedName'],
        typeName=value['Atlas Type']
        )
        if entity_from_server.get("entities") != None:
            for entity in entity_from_server.get("entities"):
                jsonData =json.dumps(entity, indent=2)
                readJSON = json.loads(jsonData)
                # print(readJSON)
                print(f"Entity {readJSON['attributes']['name']} already exists in Atlas")
                # delete_entitties(entity_from_server.get("entities"))

                # entity_from_server = client.get_entity(
                # qualifiedName= value['QualifiedName'],
                # typeName=value['Atlas Type']
                # )
                # if entity_from_server.get("entities") != None:
                #     for entity in entity_from_server.get("entities"):
                #         jsonData =json.dumps(entity, indent=2)
                #         readJSON = json.loads(jsonData)
                #         # print(readJSON)
                #         print(f"Entity {readJSON['attributes']['name']} already exists in Atlas")
                        # delete_entitties(entity_from_server.get("entities"))

                # rerìwrite this part od code
        

        
        ae = AtlasEntity(
        name = value['Nome del Dataset'],
        typeName = value['Atlas Type'], 
        qualified_name = value['QualifiedName'],
        attributes={
                        "description": value["Descrizione Dataset"],
                        "isOptional": True     
                    },
        guid = -1
        )
        
        business_attr = {}
        custom_attr = {}
        for attr in value:
            business_attr[attr]=value[attr]
        for c_attr in technical_and_operational_metadata:
            custom_attr[c_attr] = value[c_attr]
        # print(custom_attr)
        # for i in custom_attr:
        #     print(i)

        ae.addBusinessAttribute(SIAMM_business_metadata_hive_table_main1=business_attr)
        ae.addCustomAttribute(sistemaSorgente = custom_attr["Sistema Sorgente"],dataStore = custom_attr["Data Store"],schemaTarget = custom_attr["Schema Target"],primaryAndForeignKey = custom_attr["Primary Key and Foreign Key"],layerApplicativo = custom_attr["Layer applicativo"],chiaveDiPartizionamento = custom_attr["Chiave di partizionamento"],frequenzaAggiornamento = custom_attr["Frequenza d’aggiornamento "],sizing = custom_attr["Sizing"],dataCreazione = custom_attr["Data Creazione"],updateDate = custom_attr["Update date"])
        resp = client.upload_entities([ae])
        guid = resp["guidAssignments"]["-1"]
        jsonData2 = json.dumps(resp,indent=2)
        print(jsonData2)
        print(json.dumps(client.get_single_entity(guid),indent=2))
        readJSON2 = json.loads(jsonData2)

