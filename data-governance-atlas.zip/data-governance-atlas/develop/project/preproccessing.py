import pandas as pd
import atlas_type

ATLAS_TABLE_TYPE = "hive_table"
HIVE_SERVER = "jdbc:hive2://dm-work5-mo.giustizia.it:10000"
HIVE_USER = "user_acn1"

list_hive_table_type = atlas_type.get_atlas_list(ATLAS_TABLE_TYPE, HIVE_SERVER,HIVE_USER)

def create_qualifiedname(dataset):
    for value in dataset:
        qualifiedName = f"siamm://{value['Nome del Dataset'].lower()}"
        value['QualifiedName'] =  qualifiedName
    print("The qualified names were created for each table...")
    return dataset
    


def read_exel_tech_business_metadata(path):
    siamm_dataframe = pd.read_excel(path, sheet_name="Istruzioni", header=None)
    dataframe_dict_records = siamm_dataframe.to_dict(orient='records')
    values_dict = {}

    for values in dataframe_dict_records[3:]:
        values_dict[values[0]] = values[5]
    print("The Excel file with metadata was transformed to a dictionary...")
    return values_dict


def divide_columns_by_type(list_of_metadata):
    business_fillds_list = []
    tech_operational_fillds_list = []
    for key in list_of_metadata:
        if list_of_metadata[key] == 'Business':
            business_fillds_list.append(key)
        elif list_of_metadata[key] == 'Tecnico' or list_of_metadata[key] == 'Operational':
            tech_operational_fillds_list.append(key)
    # print(business_fillds_list)
    # print(tech_operational_fillds_list)
    print("Meta data was devided on technial and business fields...")
    return business_fillds_list, tech_operational_fillds_list

def convert_column_to_dict_all(path, sheet_name):
    dataset_siamm_dataframe = pd.read_excel(path, sheet_name=sheet_name)
    if sheet_name == "Colonne":
        dataset_siamm_dataframe.fillna('', inplace=True)
    elif sheet_name == "Dataset":
        dataset_siamm_dataframe["Note"].fillna(0, inplace=True)
        dataset_siamm_dataframe.fillna(0, inplace=True)
    new_dataframe = dataset_siamm_dataframe.to_dict(orient='records')
    print("Columns were transformed to a dictionary...")
    return new_dataframe

def dataframe_formatting(columns_dict_records):
    grouped_dictionary = {}
    for value in columns_dict_records:
        name = value.pop('Nome del Dataset')
        if name in grouped_dictionary:
            grouped_dictionary[name].append(value)
        else:
            grouped_dictionary[name] = [value]
    return grouped_dictionary