import json
from pyapacheatlas.core import AtlasEntity
from preproccessing import list_hive_table_type
from auth import client



def create_entities_column(formated_column_dataset, dataset_dict_records):
    list_of_qualified_names_with_type = {}
    dict_name_guid = {}
    for value in dataset_dict_records:
        if value["Nome del Dataset"].lower() in list_hive_table_type:
            value['Atlas Type'] = "hive_table"
        else:
            # print("it false hive_table")
            value['Atlas Type'] = "hive_table"

        list_of_qualified_names_with_type[value['QualifiedName']] = value['Atlas Type']

    

    for qName in list_of_qualified_names_with_type: 
        entities = client.get_entity(
        qualifiedName=qName,
        typeName=list_of_qualified_names_with_type[qName]
        )
        e = entities.get("entities")
        # print(json.dumps(e, indent=2))
        if e != None:
            dict_name_guid[qName] = e[0]["guid"]
            
    
    for table in formated_column_dataset:
        for column in formated_column_dataset[table]:
            if table.lower() in list_hive_table_type:
                column['Atlas Type'] = "hive_column"
            else:
                # print("it false hive_column")
                column['Atlas Type'] = "hive_column"

            name = column["Nome dell'Attributo"]

            entity_from_server = client.get_entity(
            qualifiedName = f'siamm://{table.lower()}_{name}_col',
            typeName = column['Atlas Type']
            )

            if entity_from_server.get("entities") != None:
                for entity in entity_from_server.get("entities"):
                    jsonData =json.dumps(entity, indent=2)
                    readJSON = json.loads(jsonData)
                    # print(readJSON)
                    print(f"Entity {readJSON['attributes']['name']} column already exists in Atlas")
                    
            else:
                for qualified_name in dict_name_guid:
                    if f'siamm://{table.lower()}' == qualified_name:    
                        name = name
                        ae = AtlasEntity(
                        name = name,
                        typeName = column['Atlas Type'],
                        qualified_name = f'siamm://{table.lower()}_{name}_col',
                        attributes={
                            "type" : 'string',
                            "data_type": column['Formato'],
                            "description": column["Descrizione dell'attributo"],
                            "isOptional": True     
                        },
                        relationshipAttributes = {'table': {'typeName': 'hive_table', 'guid': dict_name_guid[qualified_name], 'qualifiedName': f'siamm://{table.lower()}'}},

                        guid = -1
                        )
                        
                        ae.addBusinessAttribute(SIAMM_business_metadata_for_column_main={"Dati Sensibili":column["Dati Sensibili"], 
                                                                            "Range or Dominio Valori":column["Range/Dominio Valori"], 
                                                                            })

                        ae.addCustomAttribute(nullability=column["Nullability"])
                        
                        resp = client.upload_entities([ae])
                        guid = resp["guidAssignments"]["-1"]
                        jsonData3 = json.dumps(resp,indent=2)
                        print(jsonData3)
                        print(json.dumps(client.get_single_entity(guid),indent=2))
                        readJSON3 = json.loads(jsonData3)
                        print(f"Column was created")


def delete_entitties(entities):
    for entity in entities:
        guid_from_server = entity["guid"]
        delete_response = client.delete_entity(guid=guid_from_server)
        jsonDelete = json.dumps(delete_response, indent=2)
        print(jsonDelete)
        readJSON = json.loads(jsonDelete)
        print("Column was deleted...")

def delete_column_from_atlas(formated_column_dataset, dataset_dict_records):
    print("Script is looking for deleted columns in exel and delete them from database, be patient...")
    list_of_qualified_names = []
    dict_qualified_name = []
    existing_columns_qual_name =[]
    qualified_names_in_exel =[]
    for value in dataset_dict_records:
        list_of_qualified_names.append(value['QualifiedName'])

    for qulified_name in list_of_qualified_names: 
        entities = client.get_entity(
        qualifiedName=qulified_name,
        typeName="hive_table"
        )
        e = entities.get("entities")
        # print(json.dumps(e, indent=2))
        
        if e != None:
            dict_qualified_name.append(e[0]["relationshipAttributes"]["columns"])
            for value in dict_qualified_name:
                for i in value:
                    existing_columns_qual_name.append(i["qualifiedName"])
    existing_columns_qual_name = list(set(existing_columns_qual_name))  
    

    
    
    for table in formated_column_dataset:
        for column in formated_column_dataset[table]:
            name = column["Nome dell'Attributo"]
            qualifiedName = f'siamm://{table.lower()}_{name}_col'
            qualified_names_in_exel.append(qualifiedName)

    non_matched_list = list(set(existing_columns_qual_name)-set(qualified_names_in_exel))
    # print(non_matched_list)

    if len(non_matched_list) != 0:
        entities_non_matched_list = client.get_entity(
            qualifiedName=non_matched_list,
            typeName="hive_column"
            )  
        # print(entities_non_matched_list)

        if any(entities_non_matched_list):
            delete_entitties(entities_non_matched_list.get("entities"))
        else:
            print("No columns were deleted in excel file")