from preproccessing import read_exel_tech_business_metadata, divide_columns_by_type, convert_column_to_dict_all, create_qualifiedname, dataframe_formatting
from business_metadata import create_bisness_metadata_table, create_bisness_metadata_for_column
from table_entities import create_entities_dataset
from column_entities import create_entities_column, delete_column_from_atlas
from lineage import create_lineage_for_two_tables, create_lineage_for_ingestion

path_main_exel = 'develop\MdG-MetadataManagementSIAMM.xlsx' 
path_example= 'develop\MdG-MetadataManagementSIAMM_example.xlsx'
path_test_add_column = "develop\col_add_test.xlsx"
path_delete_column = "develop\col_delete_test.xlsx"
path_add_del_col = "develop\col_del_add_test.xlsx"
path_edit_attr = 'develop\diff_tech_attr_test.xlsx'
path_full_dataset_modify_table_attr = "develop\modify_full_test_dataset.xlsx"

PATH = path_main_exel


list_of_metadata = read_exel_tech_business_metadata(PATH)

tuple_of_metadatatype = divide_columns_by_type(list_of_metadata)

business_metadata_dataset = tuple_of_metadatatype[0]

technical_and_operational_metadata =tuple_of_metadatatype[1]

dataset_dict_records = convert_column_to_dict_all(PATH, sheet_name="Dataset" )

dataset_with_q_name = create_qualifiedname(dataset_dict_records)

columns_dict_records = convert_column_to_dict_all(PATH, sheet_name="Colonne" )
formated_column_dataset = dataframe_formatting(columns_dict_records)

for table in formated_column_dataset:
    for attr in formated_column_dataset[table]:
        column_keys = list(attr.keys())   
# print(column_keys)
# delete_column_from_atlas(formated_column_dataset, dataset_with_q_name)

create_bisness_metadata_table(business_metadata_dataset)
create_bisness_metadata_for_column(column_keys, business_metadata_dataset)

create_entities_dataset(dataset_with_q_name, technical_and_operational_metadata, business_metadata_dataset)
create_entities_column(formated_column_dataset, dataset_with_q_name)

# create_lineage_for_two_tables(client)
# create_lineage_for_ingestion(client)