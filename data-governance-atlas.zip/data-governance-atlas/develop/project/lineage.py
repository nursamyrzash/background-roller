import json
from pyapacheatlas.core import AtlasEntity, AtlasProcess


def create_lineage_for_two_tables(client):
    entities = client.get_entity(
        qualifiedName=["siamm://ds_siamm_dc_beneficiario_tab_fat", "siamm://ds_siamm_dc_personafisicasa_tab_dim", "siamm://ds_siamm_dc_parte_procedimento_tab_fat"],
        typeName="hive_table"
    )
    beneficiario_entity = entities.get("entities")[0]
    personaFisica_entity = entities.get("entities")[1]
    parte_procedimento = entities.get("entities")[2]
    
    process = AtlasProcess(
        name="JOIN sample process in lineage",
        typeName="Process",
        qualified_name="pyapacheatlas://democustomprocess",
        inputs=[beneficiario_entity, personaFisica_entity],
        outputs=[parte_procedimento],
        guid="-1"
    )

    results = client.upload_entities(
        batch=[process]
    )

    print(json.dumps(results, indent=2))

  
def create_lineage_for_ingestion(client):

    entity_from_server = client.get_entity(
        qualifiedName=["siamm://ds_siamm_dr_personafisicasa_tab_dim"],
        typeName="hive_table"
    )

    

    entities = client.get_entity(
        qualifiedName=["siamm://ds_siamm_dc_personafisicasa_tab_dim"],
        typeName="hive_table"
    )
    personaFisica_entity = entities.get("entities")[0]

    input01 = AtlasEntity(
        name="DS_SIAMM_DR_PERSONAFISICASA_TAB_DIM",
        typeName="hive_table",
        qualified_name="siamm://ds_siamm_dr_personafisicasa_tab_dim",
        guid="-10000003"
    )

    

    input02 = AtlasEntity(
        name="DS_SIAMM_DQ_PERSONAFISICASA_TAB_DIM",
        typeName="hive_table",
        qualified_name="siamm://ds_siamm_dq_personafisicasa_tab_dim",
        guid="-1000000"
    )

    
    
    process1 = AtlasProcess(
        name="Ingestion process",
        typeName="Process",
        qualified_name="pyapacheatlas://democustomprocess2",
        inputs=[input01],
        outputs=[input02],
        guid="-100001"
    )

    process2 = AtlasProcess(
        name="Data quality process",
        typeName="Process",
        qualified_name="pyapacheatlas://democustomprocess3",
        inputs=[input02],
        outputs=[personaFisica_entity],
        guid="-1000002"
    )

    results = client.upload_entities(
        batch=[input01, input02, process1, process2]
    )

    print(json.dumps(results, indent=2))