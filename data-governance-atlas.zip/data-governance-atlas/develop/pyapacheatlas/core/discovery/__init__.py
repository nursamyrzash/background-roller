from .purview import PurviewDiscoveryClient

__all__ = [
    "PurviewDiscoveryClient"
]
