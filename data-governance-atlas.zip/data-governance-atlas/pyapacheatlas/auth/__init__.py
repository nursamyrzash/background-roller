from .serviceprincipal import ServicePrincipalAuthentication
from .basic import BasicAuthentication
