from .purview import PurviewCollectionsClient

__all__ = [
    "PurviewCollectionsClient"
]
